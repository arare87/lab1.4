package ch.makery.address;
import java.io.IOException;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList; 
import ch.makery.address.model.Person;
import ch.makery.address.view.PersonOverviewController;

public class MainApp extends Application {

    private Stage primaryStage;
    private BorderPane rootLayout;
	private ObservableList<Person> personData = FXCollections.observableArrayList();


	@Override
	public void start(Stage primaryStage) {
		this.primaryStage = primaryStage;
        this.primaryStage.setTitle("BooksApp");
        initRootLayout();
        showPersonOverview();
	}
	 public Stage getPrimaryStage() {
	        return primaryStage;
	    }

	public MainApp() {
		personData.add(new Person("The Catcher in the Rye ", "Jerome Salinger"));
		personData.add(new Person("Jane Eyre", "Charlotte Brontë"));
	}
	public ObservableList<Person> getPersonData() {
		return personData;
	}
	 public void initRootLayout() {
		    try {
		        // Load the root layout from the fxml file.
		        FXMLLoader loader = new FXMLLoader();
		        loader.setLocation(MainApp.class.getResource("view/RootLayout.fxml"));
		        rootLayout = (BorderPane) loader.load();

		        // Display the scene containing the root layout.
		        Scene scene = new Scene(rootLayout);
		        primaryStage.setScene(scene);
		        primaryStage.show();
		        
		        // Call showPersonOverview after initializing rootLayout
		        showPersonOverview();
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		}

		public void showPersonOverview() {
		    try {
		        // Load the person overview.
		        FXMLLoader loader = new FXMLLoader();
		        loader.setLocation(MainApp.class.getResource("view/PersonOverview.fxml"));
		        AnchorPane personOverview = (AnchorPane) loader.load();

		        // Set the person overview in the center of the root layout.
		        rootLayout.setCenter(personOverview);

		        // Give the controller access to the main app.
		        PersonOverviewController controller = loader.getController();
		        controller.setMainApp(this);
		    } catch (IOException e) {
		        e.printStackTrace();
		    }
		}
		 public static void main(String[] args) {
		        launch(args);
		    }
}
