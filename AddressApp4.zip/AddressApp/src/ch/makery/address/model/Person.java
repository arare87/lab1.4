package ch.makery.address.model;

import java.time.LocalDate;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Person {

	private final StringProperty title;
	private final StringProperty authorName;
	private final StringProperty genre;
	private final StringProperty publishingHouse;
	private final IntegerProperty rating;
	private final ObjectProperty<LocalDate> dateOfPublication;

	public Person() {
		this(null, null);
	}

	public Person(String title, String authorName) {
		this.title = new SimpleStringProperty(title);
		this.authorName = new SimpleStringProperty(authorName);
		this.genre = new SimpleStringProperty("�����-�� ����");
		this.publishingHouse = new SimpleStringProperty("ooo");
		this. rating = new SimpleIntegerProperty(6);
		this.dateOfPublication = new SimpleObjectProperty<LocalDate>(LocalDate.of(1999, 2, 21));
	}

	public String getTitle() {
		return title.get();
	}

	public void setTitle(String title) {
		this.title.set(title);
	}

	public StringProperty titleProperty() {
		return title;
	}

	public String getAuthorName() {
		return authorName.get();
	}

	public void setAuthorName(String authorName) {
		this.authorName.set(authorName);
	}

	public StringProperty authorNameProperty() {
		return authorName;
	}

	public String getGenre() {
		return  genre.get();
	}

	public void setGenre(String genre) {
		this.genre.set(genre);
	}

	public StringProperty genreProperty() {
		return genre;
	}

	public String getPublishingHouse() {
		return publishingHouse.get();
	}

	public void setPublishingHouse(String publishingHouse) {
		this.publishingHouse.set(publishingHouse);
	}

	public StringProperty publishingHouseProperty() {
		return publishingHouse;
	}

	public int getRating() {
		return rating.get();
	}

	public void setRating(int rating) {
		this.rating.set(rating);
	}

	public IntegerProperty ratingProperty() {
		return rating;
	}

	public LocalDate getdateOfPublication() {
		return dateOfPublication.get();
	}

	public void setdateOfPublication(LocalDate dateOfPublication) {
		this.dateOfPublication.set(dateOfPublication);
	}

	public ObjectProperty<LocalDate> dateOfPublicationProperty() {
		return dateOfPublication;
	}
}